package com.noa.launcher.settings

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.noa.launcher.wallpaper.MotionWallpaperService
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = NoaPrefs.get(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var sens by remember { mutableFloatStateOf(NoaPrefs.sensitivity(this)) }
                var particles by remember { mutableStateOf(NoaPrefs.particles(this)) }
                val ui0 = remember { NoaPrefs.readUi(this) }
                var transparent by remember { mutableStateOf(ui0.transparentMode) }
                var level by remember { mutableFloatStateOf(ui0.transparency) }
                var blur by remember { mutableFloatStateOf(ui0.blur) }

                Column(
                    Modifier.fillMaxSize().background(Color(0xFF0B0B0D))
                        .systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text("Nôa", style = MaterialTheme.typography.headlineLarge)

                    // ---------- Aparência ----------
                    Text("Aparência", style = MaterialTheme.typography.titleMedium)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tudo transparente")
                            Text("Dock, busca, ícones e drawer ficam translúcidos",
                                style = MaterialTheme.typography.bodySmall, color = Color.White.copy(0.55f))
                        }
                        Switch(checked = transparent, onCheckedChange = {
                            transparent = it; prefs.edit().putBoolean(NoaPrefs.KEY_TRANSPARENT_MODE, it).apply()
                        })
                    }

                    if (transparent) {
                        Text("Nível de transparência: ${(level * 100).roundToInt()}%")
                        Slider(value = level, onValueChange = {
                            level = it; prefs.edit().putFloat(NoaPrefs.KEY_TRANSPARENCY, it).apply()
                        })
                    }

                    Text("Intensidade do blur: ${(blur * 100).roundToInt()}%")
                    Slider(value = blur, onValueChange = {
                        blur = it; prefs.edit().putFloat(NoaPrefs.KEY_BLUR, it).apply()
                    })
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                        Text("Blur real requer Android 12 ou superior.",
                            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(0.55f))
                    }

                    // ---------- Movimento ----------
                    Text("Movimento", style = MaterialTheme.typography.titleMedium)
                    Text("Sensibilidade: ${(sens * 100).roundToInt()}%")
                    Slider(value = sens, onValueChange = {
                        sens = it; prefs.edit().putFloat(NoaPrefs.KEY_SENSITIVITY, it).apply()
                    })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Partículas flutuantes", Modifier.weight(1f))
                        Switch(checked = particles, onCheckedChange = {
                            particles = it; prefs.edit().putBoolean(NoaPrefs.KEY_PARTICLES, it).apply()
                        })
                    }

                    Button(onClick = {
                        startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this@SettingsActivity, MotionWallpaperService::class.java)
                        ))
                    }) { Text("Definir wallpaper Nôa Motion") }
                }
            }
        }
    }
}
